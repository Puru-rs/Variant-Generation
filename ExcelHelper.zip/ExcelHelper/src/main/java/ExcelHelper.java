import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.util.SystemOutLogger;


public class ExcelHelper {

    public HSSFWorkbook readWorkbook (String excelFiltePath) {
        HSSFWorkbook workbook = null;
        try {
            FileInputStream inputStream;
            inputStream = new FileInputStream(new File(excelFiltePath));
            workbook = new HSSFWorkbook(inputStream);
            return workbook;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return workbook;
    }

    public int getRowCountOfSheet(String sheetName,HSSFWorkbook workbook) {
        HSSFSheet sheet = null;
        try {
            sheet = workbook.getSheet(sheetName);
            return sheet.getLastRowNum();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return sheet.getLastRowNum();
    }

    public int getColumnCountOfSheet(String sheetName,HSSFWorkbook workbook) {
        HSSFSheet sheet = null;
        try {
            sheet = workbook.getSheet(sheetName);
            return sheet.getRow(0).getPhysicalNumberOfCells();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return sheet.getRow(0).getPhysicalNumberOfCells();
    }

    public List<String> getRowDataWithHeader(String sheetName, int RowNumber, HSSFWorkbook workbook)throws NullPointerException{
        List<String> ExcelData = new ArrayList<String>();

        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String CellValue = null;
        String[] ary = null;
        String Value = null;
        try {
            // Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheet(sheetName);
            HSSFRow row = sheet.getRow(RowNumber);
            HSSFRow Headerrow = sheet.getRow(0);
            String Header = null;

            for (int j = 0; j <= Headerrow.getPhysicalNumberOfCells(); j++) {
                try {
                    CellType = row.getCell(j).getCellType();

                    if (CellType > -1) {
                        switch (CellType) {
                            case 0:
                                Header = Headerrow.getCell(j).toString();
                                NumericCellValue = row.getCell(j).getNumericCellValue();
                                String stringCellValue = NumericCellValue.toString();
                                ary = stringCellValue.split(Pattern.quote("."));
                                int wholeNum = Integer.parseInt(ary[0]);
                                if (NumericCellValue % wholeNum == 0) {
                                    Value = Header + "$" + ary[0];
                                } else {
                                    Value = Header + "$" + NumericCellValue;
                                }
                                ExcelData.add(Value);
                                // ExcelData.add(CellValue);
                                break;
                            case 1:
                                Header = Headerrow.getCell(j).toString();
                                CellValue = row.getCell(j).toString();
                                if (CellValue.equals("NA")) {

                                } else {
                                    String Value1 = Header + "$" + CellValue;
                                    ExcelData.add(Value1);
                                }
                                break;
                            case 3:
                            default:
                        }
                    }
                } catch (Exception expt) {
                    continue;
                }
            }
        } catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return ExcelData;
    }

    public List<String> getRowData(String sheetName,int RowNumber,HSSFWorkbook workbook)throws NullPointerException{
        List<String> ExcelData = new ArrayList<String>();

        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String CellValue = null;
        String[] ary = null;
        String Value = null;
        try {
            // Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheet(sheetName);
            HSSFRow row = sheet.getRow(RowNumber);

            for (int j = 0; j <= row.getPhysicalNumberOfCells(); j++) {
                try {
                    CellType = row.getCell(j).getCellType();

                    if (CellType > -1) {
                        switch (CellType) {
                            case 0:

                                NumericCellValue = row.getCell(j).getNumericCellValue();
                                String stringCellValue = NumericCellValue.toString();
                                ary = stringCellValue.split(Pattern.quote("."));
                                int wholeNum = Integer.parseInt(ary[0]);
                                if (NumericCellValue % wholeNum == 0) {
                                    Value = ary[0];
                                } else {
                                    Value = NumericCellValue.toString();
                                }
                                ExcelData.add(Value);
                                // ExcelData.add(CellValue);
                                break;
                            case 1:
                                CellValue = row.getCell(j).toString();
                                if (CellValue.equals("NA")) {

                                } else {
                                    String Value1 = CellValue;
                                    ExcelData.add(Value1);
                                }
                                break;
                            case 3:
                            default:
                        }
                    }
                } catch (Exception expt) {
                    continue;
                }
            }
        } catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return ExcelData;
    }

    public String getSpecificCellValue(String sheetName,int RowNumber,int ColumnNumber,HSSFWorkbook workbook)throws NullPointerException{
        List<String> ExcelData = new ArrayList<String>();

        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String CellValue = null;
        String[] ary = null;
        String Value = null;
        try {
            // Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheet(sheetName);
            HSSFRow row = sheet.getRow(RowNumber);


            try {
                CellType = row.getCell(ColumnNumber).getCellType();

                if (CellType > -1) {
                    switch (CellType) {
                        case 0:

                            NumericCellValue = row.getCell(ColumnNumber).getNumericCellValue();
                            String stringCellValue = NumericCellValue.toString();
                            ary = stringCellValue.split(Pattern.quote("."));
                            int wholeNum = Integer.parseInt(ary[0]);
                            if (NumericCellValue % wholeNum == 0) {
                                Value = ary[0];
                            } else {
                                Value = NumericCellValue.toString();
                            }

                            // ExcelData.add(CellValue);
                            break;
                        case 1:
                            CellValue = row.getCell(ColumnNumber).toString();
                            if (CellValue.equals("NA")) {

                            } else {
                                Value = CellValue;

                            }
                            break;
                        case 3:
                        default:
                    }
                }
            } catch (Exception expt) {
                expt.printStackTrace();
            }

        }
        catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return Value;
    }

    public void writeDataToNewExcelFile(String path,String sheetName,int rowNo,int cellNo,List<String> data) throws IOException {
        HSSFWorkbook myWorkBoox = new HSSFWorkbook();
        HSSFSheet mysheet = myWorkBoox.createSheet(sheetName);
        for(int j=0,i=0;j<data.size();j++,i++){
            HSSFRow myRow = mysheet.createRow(i+rowNo);
            HSSFCell myCell = myRow.createCell(cellNo);
            myCell.setCellValue(data.get(j));
        }
        FileOutputStream out = new FileOutputStream(path);
        myWorkBoox.write(out);
        out.close();
    }
}
