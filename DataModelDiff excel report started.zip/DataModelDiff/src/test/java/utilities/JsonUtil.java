package utilities;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.common.base.Strings;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class JsonUtil {
    private List<String> ignoreProperties;
    public boolean errorOutAdditionalProperties;
    //public String tenantKey, sourceKey;
    public static int totalMismatch = 1;
    public static final String REPLACE_DOT = "#DOT#";
    //public ExtentTest mdmAllLog;

    public JsonUtil(List<String> ignoreProperties, boolean errorOutAdditionalProperties) {
        this.ignoreProperties = ignoreProperties;
        this.errorOutAdditionalProperties = errorOutAdditionalProperties;
    }

    public boolean compareJsons(JsonObject sourceObject, JsonObject targetObject) {
        try {
            if (sourceObject != null && targetObject != null) {
                if (sourceObject.equals(targetObject)) {
                    //mdmAllLog.log(LogStatus.PASS, String.format("\"%s\" profile is identical with the target profile in \"%s\"", sourceKey, tenantKey));
                    return true;
                } else {
                    missingValues(sourceObject, targetObject, "");
                    for (Map.Entry<String, JsonElement> value : sourceObject.entrySet()) {
                        if (isIgnoreProperty(value.getKey())) continue;
                        String key = value.getKey();
                        if (key.contains(".")) {
                            key = key.replace(".", REPLACE_DOT);
                        }
                        if (value.getValue().isJsonPrimitive()) {
                            comparePrimitiveValue(value.getValue(), JsonRecord.getValueAsElement(targetObject, key), key, key);
                        } else if (value.getValue().isJsonObject()) {
                            compareJsonObject(value.getValue().getAsJsonObject(), JsonRecord.findObject(targetObject, key), key);
                        } else if (value.getValue().isJsonArray()) {
                            compareJsonArray(value.getValue().getAsJsonArray(), JsonRecord.findArray(targetObject, key), key, key);
                        }

                    }
                }
            }
        } catch (
                Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    private void missingValues(JsonObject sourceObject, JsonObject targetObject, String path) {
        if (this.errorOutAdditionalProperties) {
            Set<String> sourceset = (sourceObject != null) ? new HashSet<>(sourceObject.keySet()) : new HashSet<>();
            Set<String> targetset = (targetObject != null) ? new HashSet<>(targetObject.keySet()) : new HashSet<>();

            targetset.removeAll(sourceset);

            if (targetObject != null && targetset.size() > 0) {
                if (path.equals("")) {
                    System.out.println(String.format("%s. Found additional property \"%s\" in the Target JSON", totalMismatch++, targetset.toString()));
                    //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Found additional property \"%s\" in the Target JSON in %s", sourceKey, targetset.toString(), tenantKey));
                    //totalMismatch++;
                } else {
                    System.out.println(String.format("%s. Found additional property \"%s.%s\" in the Target JSON", totalMismatch++, path.replace(REPLACE_DOT, "."), targetset.toString()));
                    //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Found additional property \"%s.%s\" in the Target JSON in %s", sourceKey, path, targetset.toString(), tenantKey));
                    //totalMismatch++;
                }
            }
        }
    }

    private boolean isIgnoreProperty(String key) {
        return this.ignoreProperties != null && (this.ignoreProperties.contains(key));
    }

    private void comparePrimitiveValue(JsonElement sourceValue, JsonElement targetValue, String key, String path) {
        if (targetValue != null && targetValue.isJsonPrimitive()) {
            boolean isMatched = false;
            if (targetValue.getAsJsonPrimitive().isBoolean() && sourceValue.getAsJsonPrimitive().isBoolean()) {
                boolean source = sourceValue.getAsJsonPrimitive().getAsBoolean();
                boolean target = targetValue.getAsJsonPrimitive().getAsBoolean();
                isMatched = source == target;
            } else if (targetValue.getAsJsonPrimitive().isNumber() && sourceValue.getAsJsonPrimitive().isNumber()) {
                Number source = sourceValue.getAsJsonPrimitive().getAsNumber();
                Number target = targetValue.getAsJsonPrimitive().getAsNumber();
                isMatched = source.equals(target);
            } else if (targetValue.getAsJsonPrimitive().isString() && sourceValue.getAsJsonPrimitive().isString()) {
                String source = sourceValue.getAsJsonPrimitive().getAsString();
                String target = targetValue.getAsJsonPrimitive().getAsString();
                isMatched = source.equals(target);
            }

            if (!isMatched) {
                System.out.println(String.format("%s. Found mismatch in source \"%s\": %s and target \"%s\": %s", totalMismatch++, path.replace(REPLACE_DOT, "."), sourceValue.toString(), path.replace(REPLACE_DOT, "."), targetValue.toString()));
                //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Found mismatch in source \"%s\": %s and target \"%s\": %s in %s", sourceKey, path, sourceValue.toString(), path, targetValue.toString(), tenantKey));
                //totalMismatch++;
            }
        } else {
            System.out.println(String.format("%s. Missing property \"%s\" in the Target JSON", totalMismatch++, path.replace(REPLACE_DOT, ".")));
            //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Missing property \"%s\" in the Target JSON in %s", sourceKey, path, tenantKey));
            //totalMismatch++;
        }
    }

    private void compareJsonObject(JsonObject sourceObject, JsonObject targetObject, String path) {

        if (sourceObject != null && sourceObject.entrySet() != null && sourceObject.entrySet().size() > 0) {
            missingValues(sourceObject, targetObject, path);
            for (Map.Entry<String, JsonElement> value : sourceObject.entrySet()) {
                if (isIgnoreProperty(value.getKey())) continue;
                String key = value.getKey();
                if (key.contains(".")) {
                    key = key.replace(".", REPLACE_DOT);
                }
                String calculatedPath = (Strings.isNullOrEmpty(path)) ? key : String.format("%s.%s", path, key);
                if (value.getValue().isJsonPrimitive()) {
                    comparePrimitiveValue(value.getValue(), JsonRecord.getValueAsElement(targetObject, key), key, calculatedPath);
                } else if (value.getValue().isJsonObject()) {
                    compareJsonObject(value.getValue().getAsJsonObject(), JsonRecord.findObject(targetObject, key), calculatedPath);
                } else if (value.getValue().isJsonArray()) {
                    compareJsonArray(value.getValue().getAsJsonArray(), JsonRecord.findArray(targetObject, key), key, calculatedPath);
                }
            }
        }

    }

    private void compareJsonArray(JsonArray sourceJsonArray, JsonArray targetJsonArray, String key, String path) {
        int index = 0;
        if (sourceJsonArray != null && targetJsonArray == null) {
            System.out.println(String.format("%s. Missing property \"%s\": %s in the Target JSON", totalMismatch++, path.replace(REPLACE_DOT, "."), sourceJsonArray));
            //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Missing property \"%s\": %s in the Target JSONin %s", sourceKey, path, sourceJsonArray, tenantKey));
            //totalMismatch++;
        } else if (sourceJsonArray.size() != targetJsonArray.size()) {
            System.out.println(String.format("%s. Found mismatch in Source JSON array size %s \"%s\": %s and Target JSON array size %s \"%s\": %s", totalMismatch++, sourceJsonArray.size(), path.replace(REPLACE_DOT, "."), sourceJsonArray, targetJsonArray.size(), path.replace(REPLACE_DOT, "."), targetJsonArray));
            //mdmAllLog.log(LogStatus.FAIL, String.format("For \"%s\" profile : Found mismatch in Source JSON array size %s \"%s\": %s and Target JSON array size %s \"%s\": %s in %s", sourceKey, sourceJsonArray.size(), path, sourceJsonArray, targetJsonArray.size(), path, targetJsonArray, tenantKey));
            //totalMismatch++;
        } else {
            for (JsonElement jsonElement : sourceJsonArray) {
                String calculatedPath = String.format("%s[%s]", path, index);
                if (jsonElement.isJsonPrimitive()) {
                    comparePrimitiveValue(jsonElement, targetJsonArray.get(index), key, calculatedPath);
                } else if (jsonElement.isJsonObject()) {
                    compareJsonObject(jsonElement.getAsJsonObject(), targetJsonArray.get(index).getAsJsonObject(), calculatedPath);
                } else if (jsonElement.isJsonArray()) {
                    compareJsonArray(jsonElement.getAsJsonArray(), targetJsonArray.get(index).getAsJsonArray(), key, calculatedPath);
                }
                ++index;
            }
        }
    }
}