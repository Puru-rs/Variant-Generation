package utilities;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

public class APIUtil {

    //inovke api
    public JsonObject invokeAPI(String reqBody, String url,String tenant) {
        Response getResponse = null;
        try {
            getResponse = RestAssured.given()
                    .contentType(ContentType.JSON)
                    .header("x-rdp-version", "8.1")
                    .header("x-rdp-clientId", "rdpclient")
                    .header("x-rdp-tenantId:", tenant)
                    .header("x-rdp-ownershipData", "Nike")
                    .header("x-rdp-userId", "system_user")
                    .header("x-rdp-userName", "System User")
                    .header("x-rdp-firstName", "System")
                    .header("x-rdp-lastName", "User")
                    .header("x-rdp-userEmail", "system.user@riversand.com")
                    .header("x-rdp-userRoles", "[\"admin\"]")
                    .body(reqBody)
                    .when()
                    .post(url);

            /*com.jayway.restassured.response.Response r1 = RestAssured.given().
                    config(RestAssured.config().encoderConfig(encoderConfig().encodeContentTypeAs(reqObject.contentType, ContentType.JSON)))
                    .headers(reqObject.getHeaders()).
                            body(reqObject.getRequestJSON()).
                            when().
                            post(reqObject.getApiURL());
            *///return getResponse.getBody().toString();

        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        return new JsonParser().parse(getResponse.getBody().asString()).getAsJsonObject();
    }
}
