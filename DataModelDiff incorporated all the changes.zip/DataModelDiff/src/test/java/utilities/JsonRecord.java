package utilities;/*
   FILE: Helper.JsonRecord.java

   PURPOSE: Json record knows how to get and set the value of field from an Json record.

   COPYRIGHT: Copyright (c) 2017 Riversand Technologies, Inc. All rights reserved.

   HISTORY: 3 Feb 2017  Steve Ostlind  Created
*/

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import org.apache.commons.collections4.iterators.ArrayIterator;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import org.apache.commons.lang3.StringUtils;


/**
 * Json record knows how to get and set the value of field from an Json record.
 */
public class JsonRecord {
    private static Splitter commaSplitter = Splitter.on(",");
    private JsonObject jsonObject;
    private String type;
    String id;
    public static final String REPLACE_DOT = "#DOT#";
    private String classificationPathOriginal;
    private String classificationPath;
    private String classificationShortNamePath;

    /**
     * Constructor used when inbound record is required.
     *
     * @param jsonObject The source object.
     * @param id         The record id.
     */
    public JsonRecord(JsonObject jsonObject, String id) {
        this.jsonObject = jsonObject;
        this.id = id;
    }

    /**
     * Constructor used when outbound record is required.
     */
    public JsonRecord() {
        this.jsonObject = new JsonObject();
    }

    /**
     * Helper method to get the value of an object or return null if not found.
     *
     * @param parentElement Json parent element to begin search for child objects.
     * @param path          Child path to search. Ex: obj1.obj2.obj3 or obj1.array[1].obj2
     */
    public static String getValue(JsonElement parentElement, String path) {
        JsonElement element = findElement(parentElement, path);
        if (element != null) {
            if (element.isJsonPrimitive()) {
                JsonPrimitive primitive = (JsonPrimitive) element;
                return primitive.getAsString();
            }
        }
        return null;
    }

    /**
     * Helper method to get the value of an object or return null if not found.
     *
     * @param parentElement Json parent element to begin search for child objects.
     * @param path          Child path to search. Ex: obj1.obj2.obj3 or obj1.array[1].obj2
     */
    public static JsonElement getValueAsElement(JsonElement parentElement, String path) {
        return findElement(parentElement, path);
    }

    /**
     * Set a value in the json record.
     *
     * @param parentElement The parent element to set the value in.
     * @param path          The field path to set the value.
     * @param value         The new value of the field.
     */
    public static void setValue(JsonElement parentElement, String path, Object value, String locale, String source, String uom) {
        Map.Entry<JsonElement, String> entry = createParentPath(parentElement, path);
        JsonObject parent = entry.getKey() != null && entry.getKey().isJsonObject() ? entry.getKey().getAsJsonObject() : null;
        String field = entry.getValue();

        if (parent != null && field != null) {
            if (value instanceof Integer) {
                parent.addProperty(field, (Integer) value);
            } else if (value instanceof String) {
                parent.addProperty(field, String.valueOf(value));
            } else if (value instanceof Boolean) {
                parent.addProperty(field, (Boolean) value);
            } else {
                parent.addProperty(field, String.valueOf(value));
            }
            addAdditionalInfoToAttributeValue(parent, path, locale, source, uom);
        }
    }

    /**
     * Add source, locale and uom info to attribute value
     */
    private static void addAdditionalInfoToAttributeValue(JsonObject parent, String field, String locale, String source, String uom) {
        if (field.endsWith("].value")) {
            parent.addProperty("source", source == null ? "internal" : source);
            parent.addProperty("locale", locale == null ? "en-US" : locale);

            if (!Strings.isNullOrEmpty(uom)) {
                parent.addProperty("uom", uom);
            }
        }
    }

    /**
     * Set a value in the json record.
     *
     * @param parentElement The parent element to set the value in.
     * @param path          The field path to set the value.
     * @param value         The new value of the field.
     */
    public static void setValue(JsonElement parentElement, String path, Object value) {
        setValue(parentElement, path, value, null, null, null);
    }

    /**
     * Set a JSON object in the json record.
     *
     * @param parentElement The parent element to set the value in.
     * @param path          The field path to set the value.
     * @param jsonObject    The new value of the field.
     */
    public static void setValue(JsonElement parentElement, String path, JsonObject jsonObject) {
        Map.Entry<JsonElement, String> entry = createParentPath(parentElement, path);
        JsonObject parent = entry.getKey() != null && entry.getKey().isJsonObject() ? entry.getKey().getAsJsonObject() : null;
        String field = entry.getValue();

        if (parent != null && field != null) {
            if (parent.has(field)) {
                parent.remove(field);
            }
            parent.add(field, jsonObject);
        }
    }

    /**
     * Set a JSON object in the json record.
     *
     * @param parentElement The parent element to set the value in.
     * @param path          The field path to set the value.
     * @param jsonArray     The new value of the field.
     */
    public static void setValue(JsonElement parentElement, String path, JsonArray jsonArray) {
        Map.Entry<JsonElement, String> entry = createParentPath(parentElement, path);
        JsonObject parent = entry.getKey() != null && entry.getKey().isJsonObject() ? entry.getKey().getAsJsonObject() : null;
        String field = entry.getValue();

        if (parent != null && field != null) {
            if (parent.has(field)) {
                parent.remove(field);
            }
            parent.add(field, jsonArray);
        }
    }

    /**
     * Create the parent path in the json hierarchy.
     *
     * @return Key/value pair of parent json object and leaf field name to set the value.
     */
    private static Map.Entry<JsonElement, String> createParentPath(JsonElement parentElement, String path) {
        JsonElement currentElement = parentElement;
        JsonFieldIterator iterator = new JsonFieldIterator(path);

        while (iterator.hasNext()) {
            FieldToken fieldToken = iterator.next();

            if (currentElement == null) {
                throw new IllegalArgumentException(String.format("invalid path %s", path));
            }
            if (!currentElement.isJsonObject()) {
                throw new IllegalArgumentException(String.format("invalid expected type : %s",
                        JsonObject.class.getSimpleName(), currentElement.getClass().getSimpleName(), path));
            }

            switch (fieldToken.type) {
                case Object: {
                    JsonObject parent = (JsonObject) currentElement;
                    currentElement = parent.get(fieldToken.name);
                    if (currentElement == null) {
                        currentElement = new JsonObject();
                        parent.add(fieldToken.name, currentElement);
                    }
                    break;
                }
                case Array: {
                    // Make sure the array exists.
                    JsonObject parent = (JsonObject) currentElement;
                    String arrayName = getArrayName(fieldToken.name);
                    JsonElement arrayElement = parent.get(arrayName);
                    if (arrayElement == null) {
                        arrayElement = new JsonArray();
                        parent.add(arrayName, arrayElement);
                    }
                    if (!arrayElement.isJsonArray()) {
                        throw new IllegalArgumentException(String.format("invalid expected type : %s",
                                JsonArray.class.getSimpleName(), arrayElement.getClass().getSimpleName(), path));
                    }

                    // Make sure the array child object exists. Ex: if index=1 is referenced, then make sure index=0 and index=1 exist.
                    JsonArray array = (JsonArray) arrayElement;
                    int index = getArrayIndex(array, fieldToken.name);

                    // If index is less than zero, user searched for an index which didn't exist, add new node.
                    if (index < 0) {
                        array.add(createArrayItem(fieldToken.name));
                        index = array.size() - 1;
                    }

                    // If field is referencing array index = 5 and there are only 2 nodes, create needed nodes.
                    while (index >= array.size()) {
                        array.add(new JsonObject());
                    }

                    currentElement = array.get(index);
                    break;
                }
                case Primitive: {
                    return new AbstractMap.SimpleEntry<>(currentElement, fieldToken.name);
                }
            }
        }
        return new AbstractMap.SimpleEntry<>(currentElement, null);
    }

    /**
     * Helper method to find an array or return null if not found.
     *
     * @param parentElement Json parent element to begin search for child objects.
     * @param path          Child path to search. Ex: obj1.obj2.array or obj1.array1[1].obj3.array2
     */
    public static JsonArray findArray(JsonElement parentElement, String path) {
        JsonElement findElement = findElement(parentElement, path);
        if (findElement == null || !findElement.isJsonArray()) {
            return null;
        }
        return findElement.getAsJsonArray();
    }

    /**
     * Helper method to create an array.
     *
     * @param parentElement Json parent element to begin search for child objects.
     * @param path          Child path to search. Ex: obj1.obj2.array or obj1.array1[1].obj3.array2
     */
    public static JsonArray createArray(JsonElement parentElement, String path) {
        if (parentElement == null || !parentElement.isJsonObject()) {
            throw new IllegalArgumentException("Helper.JsonRecord cannot create array, parent is not JsonObject");
        }

        JsonArray array = new JsonArray();
        setValue(parentElement, path, array);

        return array;
    }

    /**
     * Create a json object using the field array search parameters.
     */
    private static JsonObject createArrayItem(String fieldName) {
        JsonObject jsonObject = new JsonObject();

        String expression = parseArrayIndex(fieldName);
        ContextKeyIterator iterator = new ContextKeyIterator(expression);
        while (iterator.hasNext()) {
            Map.Entry<String, String> keyValue = iterator.next();
            setValue(jsonObject, keyValue.getKey(), keyValue.getValue(), null, null, null);
        }

        return jsonObject;
    }

    /**
     * Helper method to find an object or return null if not found.
     *
     * @param parentElement Json parent element to begin search for child objects.
     * @param path          Child path to search. Ex: obj1.obj2.obj3 or obj1.array[1].obj2
     */
    public static JsonObject findObject(JsonElement parentElement, String path) {
        JsonElement findElement = findElement(parentElement, path);
        if (findElement == null || !findElement.isJsonObject()) {
            return null;
        }
        return findElement.getAsJsonObject();
    }

    /**
     * Helper method to find the element or return null if not found.
     */
    private static JsonElement findElement(JsonElement parentElement, String field) {
        JsonElement currentElement = parentElement;
        JsonFieldIterator iterator = new JsonFieldIterator(field);

        while (iterator.hasNext()) {
            FieldToken fieldToken = iterator.next();

            if (currentElement == null || !currentElement.isJsonObject()) {
                return null;
            }
            if (fieldToken.name.contains(REPLACE_DOT)) {
                fieldToken.name = fieldToken.name.replace(REPLACE_DOT , ".");
            }

            switch (fieldToken.type) {
                case Object:
                    JsonObject parent = (JsonObject) currentElement;
                    currentElement = parent.get(fieldToken.name);
                    break;
                case Array:
                    JsonObject parentObject = (JsonObject) currentElement;
                    String arrayName = getArrayName(fieldToken.name);
                    JsonElement arrayElement = parentObject.get(arrayName);
                    if (arrayElement == null || !arrayElement.isJsonArray()) {
                        return null;
                    }
                    JsonArray array = (JsonArray) arrayElement;
                    int index = getArrayIndex(array, fieldToken.name);
                    if (index < 0 || index >= array.size()) {
                        return null;
                    }
                    currentElement = array.get(index);
                    break;
                case Primitive:
                    JsonObject value = (JsonObject) currentElement;
                    currentElement = value.get(fieldToken.name);
                    break;
            }
        }

        return currentElement;
    }

    /**
     * Helper method to return field name with array index stripped off. Ex: "field[0]" => field.
     *
     * @param field The field name to parse.
     * @return Index parsed from field name.
     */
    private static String getArrayName(String field) {
        int pos = field.lastIndexOf('[');
        if (pos >= 0) {
            return field.substring(0, pos);
        }
        return field;
    }

    /**
     * Helper method to return index from field name. Ex: "field[0]" => 0.
     *
     * @param array The array to search.
     * @param field The field name to parse.
     * @return Index parsed from field name.
     */
    private static int getArrayIndex(JsonArray array, String field) {
        String indexString = parseArrayIndex(field);
        return StringUtils.isNumeric(indexString) ? Integer.parseInt(indexString) : getIndexOfArrayElement(array, indexString);
    }

    /**
     * Helper method to return index from field name. Ex: "field[0]" => "0".
     *
     * @param field The field name to parse.
     * @return Index parsed from field name.
     */
    private static String parseArrayIndex(String field) {
        int start = field.lastIndexOf('[');
        int end = field.lastIndexOf(']');
        if (start >= 0 && end >= 0 && start < end) {
            return field.substring(start + 1, end);
        }
        throw new IllegalArgumentException(String.format("Invalid Array Element : %s", field));
    }

    /**
     * Helper method to return index of first array item matching the expression. Ex: "field[o.f=value]" => index of item
     * matching 'o.f=value'.
     *
     * @param array           The array to search.
     * @param matchExpression The expression to match against each array item.
     * @return Index of matching item or -1 if not found.
     */
    private static int getIndexOfArrayElement(JsonArray array, String matchExpression) {
        int index = 0;
        for (JsonElement element : array) {
            int count = 0;
            boolean isMatch = false;
            ContextKeyIterator iterator = new ContextKeyIterator(matchExpression);
            JsonObject contextJsonObject = null;
            while (iterator.hasNext()) {
                Map.Entry<String, String> keyValue = iterator.next();
                JsonElement field = findElement(element, keyValue.getKey());
                if (field != null && field.isJsonPrimitive() && field.getAsString().equals(keyValue.getValue())) {
                    isMatch = true;
                    if (count == 0 && keyValue.getKey().contains(".")) {
                        String key = keyValue.getKey();
                        field = findElement(element, key.substring(0, key.lastIndexOf(".")));
                        if (field != null && field.isJsonObject()) {
                            contextJsonObject = field.getAsJsonObject();
                        }
                    }
                } else {
                    isMatch = false;
                    break;
                }
                count++;
            }

            if (isMatch) {
                if (contextJsonObject != null) {
                    int jsonPrimitiveCount = 0;
                    for (Map.Entry<String, JsonElement> jsonMapEntry :
                            contextJsonObject.entrySet()) {
                        if (jsonMapEntry.getValue().isJsonPrimitive()) {
                            jsonPrimitiveCount++;
                        }
                    }
                    if (jsonPrimitiveCount == count) {
                        return index;
                    }
                } else {
                    return index;
                }
            }
            index++;
        }
        return -1;
    }

    /**
     * Split the fields using separator character. Ignore separator inside array brackets. Ex: t1.t2[x.y=4] => t1,
     * t2[x.y=4].
     */
    private static List<String> splitFields(String path, String separator) {
        ArrayList<String> tokens = new ArrayList<>();

        String partialToken = null;
        for (String token : path.split(Pattern.quote(separator))) {
            if (!Strings.isNullOrEmpty(partialToken)) {
                if (hasUnbalancedArrayBraces(token)) {
                    tokens.add(partialToken + separator + token);
                    partialToken = null;
                } else {
                    partialToken += separator;
                    partialToken += token;
                }
            } else if (hasUnbalancedArrayBraces(token)) {
                partialToken = token;
            } else {
                tokens.add(token);
            }
        }

        return tokens;
    }

    private static boolean hasUnbalancedArrayBraces(String token) {
        int braceCount = 0;

        for (char c : token.toCharArray()) {
            if (c == '[') {
                braceCount++;
            } else if (c == ']') {
                braceCount--;
            }
        }

        return braceCount != 0;
    }


    /**
     * Set a value in the json record.
     *
     * @param field The field to query.
     * @param value The new value of the field.
     */
    public void setValue(String field, String value, String type) {
        setValue(jsonObject, field, value, null, null, null);
    }

    /**
     * Set a value in the json record.
     *
     * @param field The field to query.
     * @param value The new value of the field.
     * @param uom   The new uom of the field.
     */
    public void setValue(String field, String value, String uom, String type) {
        setValue(jsonObject, field, value, null, null, uom);
    }

    public void setValue(String field, String value, String locale, String source, String uom, String contextPath, String type, JsonObject properties, boolean isInheritable) {
        setValue(jsonObject, field, value, locale, source, uom);
    }

    /**
     * @return A string representation of the RSJson object after updates.
     */

    public String getString() {
        return jsonObject.toString();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return The RSJson object.
     */
    public JsonObject getJsonObject() {
        return jsonObject;
    }

    /**
     * Set the RSJson object.
     */
    public void setJsonObject(JsonObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public enum FieldType {
        Object,
        Array,
        Primitive
    }

    /**
     * Helper class to iterate a field hierarchy. Ex: obj1.obj1.arr[0].obj
     */
    private static class JsonFieldIterator implements Iterator<FieldToken> {
        private Iterator<String> fieldIterator;

        public JsonFieldIterator(String field) {
            if (!Strings.isNullOrEmpty(field)) {
                fieldIterator = splitFields(field, ".").iterator();
            }
        }

        /**
         * @return True if there are more field tokens in the message.
         */

        public boolean hasNext() {
            return fieldIterator != null && fieldIterator.hasNext();
        }

        /**
         * @return The next field token.
         */

        public FieldToken next() {
            String name = fieldIterator.next();
            FieldType type = name.contains("[") ? FieldType.Array : fieldIterator.hasNext() ? FieldType.Object : FieldType.Primitive;

            return new FieldToken(name, type);
        }

        @Override
        public void remove() {

        }
    }

    private static class FieldToken {
        public String name;
        public FieldType type;

        public FieldToken(String name, FieldType type) {
            this.name = name;
            this.type = type;
        }
    }

    public static class ContextKeyIterator implements Iterator<Map.Entry<String, String>> {
        private String contextKey;
        private ArrayIterator contextKeyIterator;

        public ContextKeyIterator(String contextKey) {
            this.contextKey = contextKey;
            if (!Strings.isNullOrEmpty(contextKey)) {
                String[] contextKeys = contextKey.split(Pattern.quote("#,#"));
                this.contextKeyIterator = new ArrayIterator(contextKeys);
            }
        }

        /**
         * @return True if there are more contexts in the record.
         */

        public boolean hasNext() {
            return contextKeyIterator != null && contextKeyIterator.hasNext();
        }

        /**
         * @return The next field token.
         */

        public Map.Entry<String, String> next() {
            String contextKey = contextKeyIterator.next().toString();
            String[] keyValue = contextKey.split(Pattern.quote("#,#"));

            if (keyValue.length == 1) {
                return new AbstractMap.SimpleEntry<>(keyValue[0], "");
            } else if (keyValue.length != 2) {
                throw new RuntimeException(String.format("Invalid format : %s", contextKey));
            }

            return new AbstractMap.SimpleEntry<>(keyValue[0], keyValue[1]);
        }

        @Override
        public void remove() {

        }
    }
}