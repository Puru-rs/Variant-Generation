package functional;

import com.google.common.base.Splitter;
import com.google.gson.*;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.plexus.util.FileUtils;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utilities.APIUtil;
import utilities.JsonRecord;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class MDM_CompareJsonDataModel {

    MDM_CompareJsonDataModel() {
        apiUtil = new APIUtil();
    }

    APIUtil apiUtil = null;
    public Splitter colonSplitter = Splitter.on(":");
    public Splitter commaSplitter = Splitter.on(",");
    String workingDir = System.getProperty("user.dir");
    String testReport = System.getProperty("user.dir") + "/testReport/";
    static List<String> excelReportingList = new ArrayList<>();
    static Map<String, List<String>> reportMap = new HashMap<>();
    static Map<String, Map<String, String>> reportMapofMap = new HashMap<>();
    Map<String, Map<String, String>> selfReportMap = new HashMap<>();
    Map<String, Map<String, String>> contextReportMap = new HashMap<>();
    static String excelReportingid = null;
    public ExtentReports mdmAllReports;
    public ExtentTest mdmAllLog;
    public static int neareastAttr, i;
    public static String testReportDate = new SimpleDateFormat("dd-MMM-yyyy_hh-mm_a").format(new Date());
    File createExcelFile = null;
    String excelFilePath = null;
    XSSFWorkbook workbook = null;
    public static boolean headersCreated = false;

    @Parameters({"riverWorksEnvName", "riverWorksTenantID", "riverWorksEntityType", "riverWorksContext", "riverWorksClassification", "clientEnvName", "clientTenantID", "clientEntityType", "clientContext", "clientClassification", "excludeProperties", "includeProperties"})
    @Test
    public void findModlDiff(String riverWorksEnvName, String riverWorksTenantID, String riverWorksEntityType, String riverWorksContext, String riverWorksClassification, String clientEnvName, String clientTenantID, String clientEntityType, String clientContext, String clientClassification, String ignoreProperties, String includeProperties) {
        try {
            FileUtils.mkdir(testReport + testReportDate);
            mdmAllReports = new ExtentReports(testReport + testReportDate + "/Attributes_ModelDiff_Riverworks_" + clientEnvName + "_" + riverWorksEnvName + ".html");
            excelFilePath = testReport + testReportDate + "/Attributes_ModelDiff_Riverworks_" + clientEnvName + "_" + riverWorksEnvName + ".xlsx";
            createExcelFile = new File(excelFilePath);
            if (!createExcelFile.exists()) {
                createExcelFile.createNewFile();
            }
            mdmAllReports.loadConfig(new File(workingDir + "/extent-config.xml"));
            List<String> clientEntityTypeList = commaSplitter.splitToList(clientEntityType);
            List<String> riverworksEntityTypeList = commaSplitter.splitToList(riverWorksEntityType);
            for (String clientEntityTypeEach : clientEntityTypeList) {
                for (String riverworksEntityTypeEach : riverworksEntityTypeList) {

                    excelReportingList.clear(); //not using
                    selfReportMap.clear();
                    contextReportMap.clear();
                    excelReportingid = null;
                    JsonObject riverworksModelObject = null;
                    JsonObject clientModelObject = null;

                    //get riverworks entity model based on entity type, only at self/global
                    if (!riverworksEntityTypeEach.equals("NA") && riverWorksContext.equals("NA") && riverWorksClassification.equals("NA")) {
                        riverworksModelObject = getModelResponse(riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach);
                    }

                    //get riverworks entity model based on entity type, only at self/global and classification only
                    if (!riverworksEntityTypeEach.equals("NA") && riverWorksContext.equals("NA") && !riverWorksClassification.equals("NA")) {
                        riverworksModelObject = getModelResponse(riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach, riverWorksClassification, "classification");
                    }

                    //get riverworks entity model based on entity type, self and context only
                    if (!riverworksEntityTypeEach.equals("NA") && !riverWorksContext.equals("NA") && riverWorksClassification.equals("NA")) {
                        riverworksModelObject = getModelResponse(riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach, riverWorksContext, "context");
                    }

                    //get riverworks entity model based on entity type, self, context and classification only
                    if (!riverWorksContext.equals("NA") && !riverWorksClassification.equals("NA")) {
                        riverworksModelObject = getModelResponse(riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach, riverWorksContext, riverWorksClassification, "both");
                    }

                    //get all attributes mapped at self only
                    JsonObject riverworksSelfAttributeObject = JsonRecord.findObject(riverworksModelObject, "response.entityModels[0].data.attributes");

                    //get all attributes mapped at context only
                    JsonObject riverworksContextfAttributeObject = JsonRecord.findObject(riverworksModelObject, "response.entityModels[0].data.contexts[0].attributes");

                    //get client entity model based on entity type and only at self/global
                    if (!clientEntityTypeEach.equals("NA") && clientContext.equals("NA") && clientClassification.equals("NA")) {
                        clientModelObject = getModelResponse(clientEnvName, clientTenantID, clientEntityTypeEach);
                    }

                    //get client entity model based on entity type, self and context only
                    if (!clientEntityTypeEach.equals("NA") && !clientContext.equals("NA") && clientClassification.equals("NA")) {
                        clientModelObject = getModelResponse(clientEnvName, clientTenantID, clientEntityTypeEach, clientContext, "context");
                    }

                    //get client entity model based on entity type, and classfification only
                    if (!clientEntityTypeEach.equals("NA") && clientContext.equals("NA") && !clientClassification.equals("NA")) {
                        clientModelObject = getModelResponse(clientEnvName, clientTenantID, clientEntityTypeEach, clientClassification, "classification");
                    }

                    //get client entity model based on entity type, self, context and classification only
                    if (!clientEntityTypeEach.equals("NA") && !clientContext.equals("NA") && !clientClassification.equals("NA")) {
                        clientModelObject = getModelResponse(clientEnvName, clientTenantID, clientEntityTypeEach, clientContext, clientClassification, "both");
                    }

                    //get all attributes mapped at self only
                    JsonObject clientSelfAttributeObject = JsonRecord.findObject(clientModelObject, "response.entityModels[0].data.attributes");

                    //get all attributes mapped at context only
                    JsonObject clientContextAttributeObject = JsonRecord.findObject(clientModelObject, "response.entityModels[0].data.contexts[0].attributes");


                    Set<String> riverWorksAttrProperties = new HashSet<>();
                    String riverworksDataType = null, clientDataType = null;
                    int count = 0;
                    // System.out.println(String.format("Entity Level Model diff between %s-%s-%s and %s-%s-%s",clientEnvName,clientTenantID,clientEntityType,clientContext,riverWorksEnvName,riverWorksTenantID,riverWorksEntityType));

                    int clientSelfAttrDiff = 0, clientSelfNearest = 0;
                    if (riverworksSelfAttributeObject != null && clientSelfAttributeObject != null) {
                        mdmAllLog = mdmAllReports.startTest("Entity Level Model diff between " + clientEntityTypeEach + " and " + riverworksEntityTypeEach);
                        //System.out.println(String.format("******Entity Level Model diff between %s-%s-%s Entity Type and %s-%s-%s Entity Type******", clientEnvName, clientTenantID, clientEntityTypeEach, riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach));
                        //    System.out.println("difference between "+clientEntityTypeEach+" and "+riverworksEntityTypeEach);
                        excelReportingid = clientEntityTypeEach + " to " + riverworksEntityTypeEach;
                        clientSelfAttrDiff = findMissingAttribute(riverworksSelfAttributeObject, clientSelfAttributeObject, riverWorksAttrProperties, riverworksDataType, clientDataType, count, ignoreProperties, includeProperties);
                        //clientSelfNearest = clientSelfAttributeObject.size() - neareastAttr;
                        clientSelfNearest = neareastAttr;
                        if (reportMapofMap.size() > 0)
                            selfReportMap = new HashMap<>(reportMapofMap);
                        reportMapofMap.clear();
                    } else {
                        System.out.println("Something went wrong, no attributes found");
                        return;
                    }
                    mdmAllReports.endTest(mdmAllLog);

                    int clientContextAttrDiff = 0, clientContextNearestAttr = 0;
                    if (riverworksContextfAttributeObject != null && clientContextAttributeObject != null) {
                        mdmAllLog = mdmAllReports.startTest("Entity Context Level Model diff between " + clientEntityTypeEach + " and " + riverworksEntityTypeEach);
                        // System.out.println("difference between "+clientEntityTypeEach+" and "+riverworksEntityTypeEach);
                        //System.out.println(String.format("*****Context Level Model diff between %s-%s-%s Entity Type - %s context and %s-%s-%s Entity Type - %s Context******", clientEnvName, clientTenantID, clientEntityTypeEach, clientContext, riverWorksEnvName, riverWorksTenantID, riverworksEntityTypeEach, riverWorksContext));
                        excelReportingid = clientEntityTypeEach + " : " + clientContext + " to " + riverworksEntityTypeEach + " : " + riverWorksContext;
                        clientContextAttrDiff = findMissingAttribute(riverworksContextfAttributeObject, clientContextAttributeObject, riverWorksAttrProperties, riverworksDataType, clientDataType, count, ignoreProperties, includeProperties);
                        //clientContextNearestAttr = clientContextAttributeObject.size() - neareastAttr;
                        clientContextNearestAttr = neareastAttr;
                        if (reportMapofMap.size() > 0)
                            contextReportMap = new HashMap<>(reportMapofMap);
                        reportMapofMap.clear();
                    } else {
                        if (!clientContext.equals("NA") && !clientClassification.equals("NA")) {
                            System.out.println("Something went wrong, no attributes found");
                        }
                    }
                    mdmAllReports.endTest(mdmAllLog);

                    if (clientContextAttrDiff == 0) {
                        mdmAllLog = mdmAllReports.startTest("Attribute Mismatch stats between :" + clientEntityTypeEach + " AND " + riverworksEntityTypeEach);
                        mdmAllLog.log(LogStatus.INFO, "********************* Self level attribute Mismatch between " + clientEntityTypeEach + " AND " + riverworksEntityTypeEach + " *************************************************");
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientSelfAttributeObject.size() + " client self level attributes, did not find : " + clientSelfAttrDiff + " in " + riverWorksTenantID);
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientSelfAttrDiff + " not found client self level attributes, found : " + clientSelfNearest + " nearest attribbutes");
                        mdmAllReports.endTest(mdmAllLog);
                        prepareExcelReport(selfReportMap);
                    }

                    if (clientContextAttrDiff > 0) {
                        mdmAllLog = mdmAllReports.startTest("Attribute Mismatch stats between :" + clientEntityTypeEach + " AND " + riverworksEntityTypeEach);
                        mdmAllLog.log(LogStatus.INFO, "********************* Self level attribute Mismatch between " + clientEntityTypeEach + " AND " + riverworksEntityTypeEach + " *************************************************");
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientSelfAttributeObject.size() + " client self level attributes, did not find : " + clientSelfAttrDiff + " in " + riverWorksTenantID);
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientSelfAttrDiff + " not found client self level attributes, found : " + clientSelfNearest + " nearest attribbutes");
                        mdmAllLog.log(LogStatus.INFO, "************************** Context level attribute Mismatch between " + clientEntityTypeEach + " AND " + riverworksEntityTypeEach + " **************************************************");
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientContextAttributeObject.size() + " client context level attributes, did not find : " + clientContextAttrDiff + " in " + riverWorksTenantID);
                        mdmAllLog.log(LogStatus.INFO, "Out of : " + clientContextAttrDiff + " not found client context level attributes, found : " + clientContextNearestAttr + " nearest attribbutes");
                        mdmAllReports.endTest(mdmAllLog);
                        prepareExcelReport(selfReportMap, contextReportMap);
                    }
                    FileOutputStream outputStream = new FileOutputStream(excelFilePath);
                    workbook.write(outputStream);
                }
            }


        } catch (Exception ex) {
            System.out.println("Some thing went wrong");
            ex.printStackTrace();
        }
    }

    private void prepareExcelReport(Map<String, Map<String, String>> selfReportMap) throws Exception {
        Map<String, Map<String, String>> contextReportMap = new HashMap<>();
        contextReportMap = null;
        prepareExcelReport(selfReportMap, contextReportMap);

    }

    private void prepareExcelReport(Map<String, Map<String, String>> selfReportMap, Map<String, Map<String, String>> contextReportMap) throws Exception {
        String individualPropertyName = "", scenarioID = "";
        if (createExcelFile.length() > 0) {
            File f = new File(createExcelFile.toString());
            FileInputStream ios = new FileInputStream(f);
            workbook = new XSSFWorkbook(ios);
            workbook.getSheet("Client Attribute Difference");

            printReportInExcel(selfReportMap, workbook);

            if (contextReportMap != null) {
                printReportInExcel(contextReportMap, workbook);
            }


        } else {
            FileInputStream ios = new FileInputStream(createExcelFile);

            workbook = new XSSFWorkbook();
            workbook.createSheet("Client Attribute Difference");

        /*cell = workbook.getSheet("Client Attribute Difference").getRow(0).getCell(1);
        cell.setCellValue("");*/


            printReportInExcel(selfReportMap, workbook);

            if (contextReportMap != null) {
                printReportInExcel(contextReportMap, workbook);
            }

        }
      /*  for (Map.Entry<String, List<String>> loopSelfAttribute : selfReportMap.entrySet()) {
            for (int i = 1; i < loopSelfAttribute.getValue().size(); i++) {
                if (i == 0) {
                    scenarioID = loopSelfAttribute.getValue().get(i);
                } else {
                    if (i != loopSelfAttribute.getValue().size() - 1) {
                        individualPropertyName = individualPropertyName + loopSelfAttribute.getValue().get(i) + ",";
                    } else {
                        individualPropertyName = individualPropertyName + loopSelfAttribute.getValue().get(i);
                    }

                }
            }*/
        //System.out.println(scenarioID + " : " + loopSelfAttribute.getKey() + " : " + individualPropertyName);
    }

    private void printReportInExcel(Map<String, Map<String, String>> reportMap, XSSFWorkbook workbook) {
        XSSFCell cell;
        XSSFSheet sheet = workbook.getSheet("Client Attribute Difference");
        XSSFRow row = sheet.getRow(0);
        Map<String, Integer> headerRow = new HashMap<>();
        if (row == null) {
            row = sheet.createRow(0);
            cell = row.createCell(0);
            cell.setCellValue("Scenario");
        }
        for (int i = 0; i < row.getLastCellNum(); i++) {
            headerRow.put(row.getCell(i).toString(), i);
        }
        int rowCount = workbook.getSheet("Client Attribute Difference").getLastRowNum();
        for (Map.Entry<String, Map<String, String>> loopSelfAttribute : reportMap.entrySet()) {
            Row newRow = sheet.createRow(++rowCount);
            loopSelfAttribute.getValue().put("Attribute Name", loopSelfAttribute.getKey());
            for (Map.Entry<String, String> value :
                    loopSelfAttribute.getValue().entrySet()) {
                if (headerRow.containsKey(value.getKey())) {
                    Cell newRowCell = newRow.createCell(headerRow.get(value.getKey()));
                    newRowCell.setCellValue(value.getValue());
                } else {
                    Integer lastnum = (int) row.getLastCellNum();
                    headerRow.put(value.getKey(), lastnum);
                    row.createCell(lastnum).setCellValue(value.getKey());
                    Cell newRowCell = newRow.createCell(lastnum);
                    newRowCell.setCellValue(value.getValue());
                }
            }
        }
    }
    /*private void printReportInExcel(Map<String, List<String>> reportMap, XSSFWorkbook workbook) {
        XSSFCell cell;
        int rowCount = workbook.getSheet("Client Attribute Difference").getLastRowNum();
        XSSFSheet sheet = workbook.getSheet("Client Attribute Difference");
        if (rowCount == 0) {
            XSSFRow row = sheet.createRow(rowCount);
            cell = row.createCell(0);
            cell.setCellValue("Scenario");
            cell = row.createCell(1);
            cell.setCellValue("Attribute Name");
            cell = row.createCell(2);
            cell.setCellValue("Data Type");
            cell = row.createCell(3);
            cell.setCellValue("Display Type");
            cell = row.createCell(4);
            cell.setCellValue("Attribute Properties");
            headersCreated = true;
        }
        rowCount = workbook.getSheet("Client Attribute Difference").getLastRowNum();
        if (headersCreated) {
            i = rowCount + 1;
            for (Map.Entry<String, List<String>> loopSelfAttribute : reportMap.entrySet()) {
                XSSFRow row = sheet.createRow(i);
                int propertiesSize = loopSelfAttribute.getValue().size();
                for (int j = 0; j < propertiesSize; j++) {

                    XSSFCell valueCell = row.createCell(j);
                    if (j == 0) {
                        valueCell.setCellValue(loopSelfAttribute.getValue().get(0));
                        continue;
                    } else if (j == 1) {
                        //valueCell = sheet.getRow(i).getCell(1);
                        valueCell.setCellValue(loopSelfAttribute.getKey());
                        continue;
                    } else if (j == 2) {
                        // valueCell = sheet.getRow(i).getCell(2);
                        for (int k = 0; k < propertiesSize; k++) {
                            if (loopSelfAttribute.getValue().get(k).split(Pattern.quote(":"))[0].equalsIgnoreCase("datatype")) {
                                valueCell.setCellValue(loopSelfAttribute.getValue().get(k).split(Pattern.quote(":"))[1].trim());
                                break; //hhhhhhhhyhgtyghtygghy
                            }
                        }
                    } else if (j == 3) {
                        // valueCell = sheet.getRow(i).getCell(3);
                        for (int l = 0; l < propertiesSize; l++) {
                            if (loopSelfAttribute.getValue().get(l).split(Pattern.quote(":"))[0].equalsIgnoreCase("displaytype")) {
                                valueCell.setCellValue(loopSelfAttribute.getValue().get(l).split(Pattern.quote(":"))[1].trim());
                                break;
                            }
                        }
                    } else if (j >= 4) {
                        for (int r = 1; r < propertiesSize; r++) {
                            //  valueCell = sheet.getRow(i).getCell(j);
                            if (!loopSelfAttribute.getValue().get(r).split(Pattern.quote(":"))[0].equalsIgnoreCase("displaytype")) {
                                if (!loopSelfAttribute.getValue().get(r).split(Pattern.quote(":"))[0].equalsIgnoreCase("datatype")) {
                                    {
                                        valueCell.setCellValue(loopSelfAttribute.getValue().get(r));
                                        XSSFCell valueCell1 = row.createCell(j);
                                        valueCell = valueCell1;
                                        j++;
                                    }
                                }
                            }
                        }
                    }
                }
                i++;
            }
        }
    }*/

    private int findMissingAttribute(JsonObject riverworksAttributeObject, JsonObject clientAttributeObject, Set<String> riverWorksAttrProperties, String riverworksDataType, String clientDataType, int count, String ignoreProperties, String includeProperties) {
        boolean identical = true;
        boolean clientIncluded = false;
        boolean riverworksIncluded = false;
        List<String> ignorePropertiesList = Arrays.asList(ignoreProperties.split(Pattern.quote(",")));
        List<String> includePropertiesList = Arrays.asList(includeProperties.split(Pattern.quote(",")));
        Set<String> clientAttributeNotFoundSet = new HashSet<>();
        int totalMismatchFoundAttr = 0;
        neareastAttr = 0;

        for (Map.Entry<String, JsonElement> clientAttributeEntitySet : clientAttributeObject.entrySet()) {
            String clientAttribute = clientAttributeEntitySet.getKey();
            /*if (clientAttributeEntitySet.getKey().equals("createdate")) { //for debug
                System.out.print("");
            }*/
            count++;
            String foundRiverworksAttributeName = null;
            String key = clientAttributeEntitySet.getKey(); //client attribute name
            Set<String> clientAttrProperties = new HashSet<>();
            Set<String> clientAttrPropertiesForPrinting = new HashSet<>();
            Map<String, String> clientAttrPropertiesForPrintingMap = new HashMap<>();
            Set<String> riverWorksNearestAttribute = new HashSet<>();
            riverWorksNearestAttribute = null;
            boolean matchFound = false, printNotFound = true;
            JsonElement clientAttributeElement = clientAttributeEntitySet.getValue();
            if (clientAttributeElement.isJsonObject()) {
                JsonObject clientPropObject = JsonRecord.findObject(clientAttributeElement, "properties");

                for (Map.Entry<String, JsonElement> clientProperyEntrySet : clientPropObject.entrySet()) {
                    outerclient:
                    for (Map.Entry<String, JsonElement> clientAttrEntrySet : clientPropObject.entrySet()) {
                        clientIncluded = false;
                        if (clientAttrEntrySet.getKey().equals("dataType")) {
                            clientDataType = clientAttrEntrySet.getValue().toString();
                            clientAttrPropertiesForPrinting.add(clientAttrEntrySet.getKey() + ":" + clientAttrEntrySet.getValue().toString().replace("\"", ""));
                        } else {
                            //This loop will decide exclude property
                            for (String ignoreProperty : ignorePropertiesList) {
                                if (ignoreProperty.equalsIgnoreCase(clientAttrEntrySet.getKey())) {
                                    continue outerclient;
                                }
                            }
                            //This loop will decide include property
                            for (String includeProperty : includePropertiesList) {
                                if (includeProperty.equalsIgnoreCase(clientAttrEntrySet.getKey())) {
                                    clientAttrProperties.add(clientAttrEntrySet.getKey());
                                    clientAttrPropertiesForPrinting.add(clientAttrEntrySet.getKey() + ":" + clientAttrEntrySet.getValue().toString().replace("\"", ""));
                                    clientAttrPropertiesForPrintingMap.put(clientAttrEntrySet.getKey(), clientAttrEntrySet.getValue().toString().replace("\"", ""));
                                    clientIncluded = true;
                                    continue outerclient;

                                }
                            }

                            if (clientIncluded == false && !includeProperties.equalsIgnoreCase("na")) {
                                continue outerclient;
                            }

                            //properties will be added to riverWorksAttrProperties list only when includeProperties is set to na
                            clientAttrProperties.add(clientAttrEntrySet.getKey());
                            clientAttrPropertiesForPrinting.add(clientAttrEntrySet.getKey() + ":" + clientAttrEntrySet.getValue().toString().replace("\"", ""));
                            clientAttrPropertiesForPrintingMap.put(clientAttrEntrySet.getKey(), clientAttrEntrySet.getValue().toString().replace("\"", ""));
                        }

                    }
                    String clientKey = clientProperyEntrySet.getKey();   //datatype
                    String clientValue = clientProperyEntrySet.getValue().toString();
                    if (clientKey.equals("uomEntityInfo")) continue;
                    //System.out.println(clientKey + ": " + clientValue);
                    int i = 0;
                    for (Map.Entry<String, JsonElement> riverworksAttributeEntitySet : riverworksAttributeObject.entrySet()) { //get all rw attribute
                        i++;
                       /* if (i == 341) {
                            System.out.println("");
                        }*/
                        String riverworksAttributeName = riverworksAttributeEntitySet.getKey();
                       /* if (riverworksAttributeEntitySet.getKey().equals("materialcluster")) { //for debug
                            System.out.print("");
                        }*/
                        JsonElement riverworksAttributeElement = riverworksAttributeEntitySet.getValue();
                        if (riverworksAttributeElement.isJsonObject()) {
                            JsonObject riverworksPropObject = JsonRecord.findObject(riverworksAttributeElement, "properties");
                            for (Map.Entry<String, JsonElement> riverworksPropertyEntrySet : riverworksPropObject.entrySet()) {
                                String riverworksKey = riverworksPropertyEntrySet.getKey();
                                String riverworksValue = riverworksPropertyEntrySet.getValue().toString();

                                riverWorksAttrProperties.clear();
                                outerRiverworks:
                                for (Map.Entry<String, JsonElement> riverworksAttrEntrySet : riverworksPropObject.entrySet()) {
                                    riverworksIncluded = false;
                                    if (riverworksAttrEntrySet.getKey().equals("dataType")) {
                                        riverworksDataType = riverworksAttrEntrySet.getValue().toString();
                                    } else {
                                        //This loop will decide exclude property
                                        for (String ignoreProperty : ignorePropertiesList) {
                                            if (ignoreProperty.equalsIgnoreCase(riverworksAttrEntrySet.getKey())) {
                                                continue outerRiverworks;
                                            }
                                        }

                                        //This loop will decide include property
                                        for (String includeProperty : includePropertiesList) {
                                            if (includeProperty.equalsIgnoreCase(riverworksAttrEntrySet.getKey())) {
                                                riverWorksAttrProperties.add(riverworksAttrEntrySet.getKey());
                                                riverworksIncluded = true;
                                                continue outerRiverworks;

                                            }
                                        }

                                        if (riverworksIncluded == false && !includeProperties.equalsIgnoreCase("na")) {
                                            continue outerRiverworks;
                                        }

                                        //properties will be added to riverWorksAttrProperties list only when includeProperties is set to na
                                        riverWorksAttrProperties.add(riverworksAttrEntrySet.getKey());

                                    }
                                }
                                if (clientDataType.equals(riverworksDataType)) {
                                    if (clientAttrProperties.equals(riverWorksAttrProperties)) {
                                        //System.out.println(String.format("%s. Found ,\"%s\", attribute with \"%s\"", count, key, clientAttrProperties));
                                        matchFound = true;
                                        break;
                                    } else {
                                        if (i == riverworksAttributeObject.size() && riverWorksNearestAttribute == null) {
                                            if (printNotFound) {
                                                totalMismatchFoundAttr++;
                                                mdmAllLog.log(LogStatus.FAIL, "Did not find <b><i>\"" + key + "\"</i></b> attribute with " + clientAttrPropertiesForPrinting);
                                                prepareReportList(key, clientAttrPropertiesForPrinting);
                                                clientAttrPropertiesForPrintingMap.put("Nearest Match","NO");
                                                prepareReportList(key, clientAttrPropertiesForPrintingMap);
                                                //System.out.println(String.format("%s. Did not find ,\"%s\", attribute with \"%s\"", count, key, clientAttrPropertiesForPrinting));
                                            }
                                            printNotFound = false;
                                            identical = false;
                                        }
                                        //to find the nearest match
                                        if (riverWorksNearestAttribute == null) {
                                            riverWorksNearestAttribute = findNearestMatch(clientAttrProperties, riverWorksAttrProperties);
                                            if (riverWorksNearestAttribute != null) {
                                                foundRiverworksAttributeName = riverworksAttributeName;
                                            }
                                        }
                                        if (i == riverworksAttributeObject.size() && riverWorksNearestAttribute != null) {
                                            if (printNotFound) {
                                                totalMismatchFoundAttr++;
                                                neareastAttr++;
                                                mdmAllLog.log(LogStatus.FAIL, "Did not find <b><i>\"" + key + "\"</i></b> attribute with " + clientAttrPropertiesForPrinting + " <br />Found nearest attribute in riverworks : <b><i>\"" + foundRiverworksAttributeName + "\"</i></b>" + riverWorksNearestAttribute);
                                                clientAttrPropertiesForPrintingMap.put("Nearest Match","YES");
                                                clientAttrPropertiesForPrintingMap.put("Nearest Attribute",foundRiverworksAttributeName);
                                                clientAttrPropertiesForPrintingMap.put("Nearest Properties",riverWorksNearestAttribute.toString());
                                                prepareReportList(key, clientAttrPropertiesForPrintingMap);
                                            }
                                            printNotFound = false;
                                            identical = false;
                                        }


                                    }
                                    continue;
                                } else {
                                    if (i == riverworksAttributeObject.size() && matchFound == false && riverWorksNearestAttribute == null) {
                                        if (printNotFound) {
                                            totalMismatchFoundAttr++;
                                            mdmAllLog.log(LogStatus.FAIL, "Did not find <b><i>\"" + key + "\"</i></b> attribute with " + clientAttrPropertiesForPrinting);
                                            //System.out.println(String.format("%s. Did not find ,\"%s\", attribute with \"%s\"", count, key, clientAttrPropertiesForPrinting));
                                            prepareReportList(key, clientAttrPropertiesForPrinting);
                                            clientAttrPropertiesForPrintingMap.put("Nearest Match","NO");
                                            prepareReportList(key, clientAttrPropertiesForPrintingMap);
                                        }
                                        printNotFound = false;
                                        identical = false;
                                        //break;
                                    }
                                    if (i == riverworksAttributeObject.size() && matchFound == false && riverWorksNearestAttribute != null) {
                                        if (printNotFound) {
                                            totalMismatchFoundAttr++;
                                            neareastAttr++;
                                            mdmAllLog.log(LogStatus.FAIL, "Did not find <b><i>\"" + key + "\"</i></b> attribute with " + clientAttrPropertiesForPrinting + " <br />Found nearest attribute in riverworks : <b><i>\"" + foundRiverworksAttributeName + "\"</i></b>" + riverWorksNearestAttribute);
                                            clientAttrPropertiesForPrintingMap.put("Nearest Match","YES");
                                            clientAttrPropertiesForPrintingMap.put("Nearest Attribute",foundRiverworksAttributeName);
                                            clientAttrPropertiesForPrintingMap.put("Nearest Properties",riverWorksNearestAttribute.toString());
                                            prepareReportList(key, clientAttrPropertiesForPrintingMap);
                                        }
                                        printNotFound = false;
                                        identical = false;
                                    }
                                    break;
                                }
                            }
                        }
                        if (matchFound)
                            break;
                    }
                    if (matchFound)
                        break;//not break


                }
            } else {
                System.out.println("Did not find as an Object");
            }
        }
        if (identical) {
            System.out.println("Attribute model is identical..");
            mdmAllLog.log(LogStatus.PASS, "All the Client attribute properties are found in Riverwork attribute properties");
        }
        return totalMismatchFoundAttr;
    }

    private void prepareReportList(String key, Set<String> clientAttrPropertiesForPrinting) {
        List<String> prepareList = new ArrayList<>();
        prepareList.add(excelReportingid);
        for (String clientAttributeProperty : clientAttrPropertiesForPrinting)
            prepareList.add(clientAttributeProperty);
        reportMap.put(key, prepareList);
    }

    private void prepareReportList(String key, Map<String, String> clientAttrPropertiesForPrintingMap) {
        clientAttrPropertiesForPrintingMap.put("Scenario", excelReportingid);
        reportMapofMap.put(key, clientAttrPropertiesForPrintingMap);
    }

    private Set<String> findNearestMatch(Set<String> clientAttrProperties, Set<String> riverWorksAttrProperties) {
        Set<String> riverworksNearestAttribute = new HashSet<>();
        for (String clientProperty : clientAttrProperties) {
            for (String riverworkProperty : riverWorksAttrProperties) {
                if (clientProperty.equals(riverworkProperty)) {
                    riverworksNearestAttribute.add(riverworkProperty);
                }
            }
        }
        if (clientAttrProperties.equals(riverworksNearestAttribute)) {
            return new HashSet<>(riverWorksAttrProperties);
        } else {
            return null;
        }
    }

    // get model based on self, clssification or context
    private JsonObject getModelResponse(String webUrl, String tenant, String entityType, String context, String contextType) {
        String riverWorksModelRequest = null;
        String riverworksURL = getMangeURL(webUrl, tenant, "entityappmodelservice", "getcomposite");
        if (contextType.equalsIgnoreCase("context")) {
            riverWorksModelRequest = preparteModelJsonRequestwithContext(entityType, context);
        } else if (contextType.equalsIgnoreCase("classification")) {
            riverWorksModelRequest = preparteModelJsonRequestWithClassification(entityType, context);
        }

        JsonObject modelResponse = apiUtil.invokeAPI(riverWorksModelRequest, riverworksURL, tenant);
        //return JsonRecord.findObject(modelResponse, "response.entityModels[0].data.attributes");
        return modelResponse;
    }

    private JsonObject getModelResponse(String webUrl, String tenant, String entityType) {
        String riverworksURL = getMangeURL(webUrl, tenant, "entityappmodelservice", "getcomposite");
        String riverWorksModelRequest = preparteModelJsonRequest(entityType);
        JsonObject modelResponse = apiUtil.invokeAPI(riverWorksModelRequest, riverworksURL, tenant);
        //return JsonRecord.findObject(modelResponse, "response.entityModels[0].data.attributes");
        return modelResponse;
    }


    private JsonObject getModelResponse(String webUrl, String tenant, String entityType, String context, String
            classification, String both) {
        String riverworksURL = getMangeURL(webUrl, tenant, "entityappmodelservice", "getcomposite");
        String riverWorksModelRequest = preparteModelJsonRequest(entityType, context, classification);
        JsonObject modelResponse = apiUtil.invokeAPI(riverWorksModelRequest, riverworksURL, tenant);
        //return JsonRecord.findObject(modelResponse, "response.entityModels[0].data.attributes");
        return modelResponse;
    }

    private String getMangeURL(String url, String tenant, String service, String api) {
        return "http://manage." + url + ".riversand-dataplatform.com:8085/" + tenant + "/api/" + service + "/" + api;
    }

    private void prepareJsonRequestForModelServiceGet(JsonObject newElement, JsonArray
            attributeModelArray, JsonArray allArray, String individualDataType) {
        JsonRecord.setValue(newElement, "params.query.filters.propertiesCriterion[0].dataType.exact", individualDataType.trim());

        JsonRecord.setValue(newElement, "params.query.filters.typesCriterion", attributeModelArray);

        JsonRecord.setValue(newElement, "params.fields.attributes", allArray);
        JsonRecord.setValue(newElement, "params.fields.relationships", allArray);
    }

    //prepare get model json request based on entity and context only
    private String preparteModelJsonRequestwithContext(String entityType, String context) {
        JsonObject newElement = new JsonObject();
        JsonArray typesCriterianArray = new JsonArray(), allArray = new JsonArray();
        typesCriterianArray.add("entityManageModel");
        typesCriterianArray.add("entityValidationModel");
        typesCriterianArray.add("entityDisplayModel");

        colonSplitter = Splitter.on(":");

        List<String> contextDetails = colonSplitter.splitToList(context);

        allArray.add("_ALL");

        JsonRecord.setValue(newElement, "params.query.contexts[0]." + contextDetails.get(0).trim(), contextDetails.get(1).trim());

        JsonRecord.setValue(newElement, "params.query.id", entityType + "_entityManageModel");

        JsonRecord.setValue(newElement, "params.query.filters.typesCriterion", typesCriterianArray);

        JsonRecord.setValue(newElement, "params.fields.attributes", allArray);

        return newElement.toString();
    }

    //prepare model get json request based on entity type only
    private String preparteModelJsonRequest(String entityType) {
        JsonObject newElement = new JsonObject();
        JsonArray typesCriterianArray = new JsonArray(), allArray = new JsonArray();
        typesCriterianArray.add("entityManageModel");
        typesCriterianArray.add("entityValidationModel");
        typesCriterianArray.add("entityDisplayModel");

        allArray.add("_ALL");

        JsonRecord.setValue(newElement, "params.query.id", entityType + "_entityManageModel");

        JsonRecord.setValue(newElement, "params.query.filters.typesCriterion", typesCriterianArray);

        JsonRecord.setValue(newElement, "params.fields.attributes", allArray);

        return newElement.toString();
    }

    //prepare model get json request based on entity type, Context and classification
    private String preparteModelJsonRequest(String entityType, String context, String classification) {
        JsonObject newElement = new JsonObject();
        JsonArray typesCriterianArray = new JsonArray(), allArray = new JsonArray(), contextOption = new JsonArray();
        typesCriterianArray.add("entityManageModel");
        typesCriterianArray.add("entityValidationModel");
        typesCriterianArray.add("entityDisplayModel");

        contextOption.add(context);

        colonSplitter = Splitter.on(":");

        List<String> classificationDetails = colonSplitter.splitToList(classification);

        colonSplitter = Splitter.on(":");

        List<String> contextDetails = colonSplitter.splitToList(context);

        allArray.add("_ALL");

        JsonRecord.setValue(newElement, "params.query.contexts[0]." + contextDetails.get(0).trim(), contextDetails.get(1).trim());

        JsonRecord.setValue(newElement, "params.query.id", entityType + "_entityManageModel");

        JsonRecord.setValue(newElement, "params.query.filters.typesCriterion", typesCriterianArray);

        JsonRecord.setValue(newElement, "params.fields.attributes", allArray);

        JsonRecord.setValue(newElement, "params.options.coalesceOptions.enhancerAttributes[0]." + classificationDetails.get(0).trim(), classificationDetails.get(1).trim());

        JsonRecord.setValue(newElement, "params.options.coalesceOptions.enhancerAttributes[0].contexts[0].self", "self");

        return newElement.toString();
    }

    //prepare model get json request based on entity type and classification
    private String preparteModelJsonRequestWithClassification(String entityType, String classification) {
        JsonObject newElement = new JsonObject();
        JsonArray typesCriterianArray = new JsonArray(), allArray = new JsonArray(), contextOption = new JsonArray();
        typesCriterianArray.add("entityManageModel");
        typesCriterianArray.add("entityValidationModel");
        typesCriterianArray.add("entityDisplayModel");

        colonSplitter = Splitter.on(":");

        List<String> classificationDetails = colonSplitter.splitToList(classification);

        allArray.add("_ALL");

        JsonRecord.setValue(newElement, "params.query.id", entityType + "_entityManageModel");

        JsonRecord.setValue(newElement, "params.query.filters.typesCriterion", typesCriterianArray);

        JsonRecord.setValue(newElement, "params.fields.attributes", allArray);

        JsonRecord.setValue(newElement, "params.options.coalesceOptions.enhancerAttributes[0]." + classificationDetails.get(0).trim(), classificationDetails.get(1).trim());

        JsonRecord.setValue(newElement, "params.options.coalesceOptions.enhancerAttributes[0].contexts[0].self", "self");

        return newElement.toString();
    }

    private String readJsonFile(String path) throws IOException {
        JsonObject modelRequestJson = null;
        try {
            String modelRequest = new String(Files.readAllBytes(Paths.get(path)));
            modelRequestJson = new JsonParser().parse(modelRequest).getAsJsonObject();
            return modelRequestJson.toString();
        } catch (
                Exception ex) {
            ex.printStackTrace();
        }
        return modelRequestJson.toString();
    }

    @AfterTest
    public void endReport() {
        mdmAllReports.flush();
        mdmAllReports.close();
    }

    @AfterSuite
    public void writeToExcel() {
        try {
            FileOutputStream outputStream = new FileOutputStream(excelFilePath);
            workbook.write(outputStream);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
