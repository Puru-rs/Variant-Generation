package utilities;


import com.google.common.base.Strings;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
//import org.testng.util.Strings;

import java.util.*;

import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.logging.log4j.core.util.Assert.isNonEmpty;

public final class ExcelUtil {

    private ExcelUtil() {
    }

    public static boolean isEmptyRow(Row row) {
        if (row == null) {
            return true;
        }

        if (row.getLastCellNum() <= 0) {
            return true;
        }

        for (Iterator<Cell> iter = row.cellIterator(); iter.hasNext(); ) {
            Cell cell = iter.next();

            if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK) {
                if (cell.getCellType() == Cell.CELL_TYPE_STRING && !cell.getStringCellValue().isEmpty()) {
                    return false;
                } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
                    return false;
                }
            }
        }

        return true;
    }

    public static Boolean booleanOrNull(String value) {
        return isNonEmpty(value) ? booleanOrFalse(value) : null;
    }

    public static Boolean booleanOrFalse(String value) {
        return isNonEmpty(value) && StringUtils.containsAny(value.toLowerCase(), "yt");
    }

    public static String stringOrNull(String value) {
        return isNonEmpty(value) ? value : null;
    }

    public static String stringOrDefaultValue(String value, String defaultValue) {
        return isNonEmpty(value) ? value : defaultValue;
    }

    public static Integer intOrNull(String value) {
        return isNonEmpty(value) && NumberUtils.isCreatable(value) ? NumberUtils.createNumber(value).intValue() : null;
    }

    public static Number numberOrNull(String value) {
        return isNonEmpty(value) && NumberUtils.isCreatable(value) ? NumberUtils.createNumber(value) : null;
    }


    public static Map<String, List<Map<String, String>>> toMapOfMapList(List<Map<String, String>> entityRows) {
        Map<String, List<Map<String, String>>> listMap = new HashMap<>();
        if (entityRows != null) {
            for (Map<String, String> entityMap :
                    entityRows) {
                String name = entityMap.get("NAME");
                listMap.computeIfAbsent(name, k -> new ArrayList<>()).add(entityMap);
            }
        }
        return listMap;
    }


    public static boolean createStringCell(XSSFRow row, Integer number, Object value) {
        if (number != null) {
            Optional.ofNullable(value).ifPresent(v -> row.createCell(number).setCellValue(String.valueOf(value)));
            return true;
        }

        return false;

    }

    public static boolean createDoubleCell(XSSFRow row, Integer number, Object value) {
        if (number == null) {
            return false;
        }

        if (value != null && value instanceof String) {
            createStringCell(row, number, value);
        } else {
            Optional.ofNullable(value).ifPresent(v -> row.createCell(number).setCellValue((Integer) v));
        }
        return true;
    }

    public static Map<String, Integer> readColumns(XSSFSheet sheet, int rowNo) {
        Map<String, Integer> columns = new TreeMap<>();
        if (sheet != null) {
            XSSFRow header = sheet.getRow(rowNo);
            for (Cell headerCell : header) {
                String value = headerCell.getStringCellValue();
                if (isBlank(value)) {
                    break;
                }

                columns.put(value, headerCell.getColumnIndex());
            }
        }
        return columns;
    }

    public static Map<String, String> getValues(Map<String, Integer> importHeaderMap, Row row, boolean putEmptyValue) {
        Map<String, String> valueMap = new TreeMap<>();
        if (row != null) {
            for (Map.Entry<String, Integer> importHeaderMapEntry :
                    importHeaderMap.entrySet()) {
                String headerName = importHeaderMapEntry.getKey();
                Integer index = importHeaderMapEntry.getValue();
                Cell excelCell = row.getCell(index);
                String value = excelCell != null ? new DataFormatter().formatCellValue(excelCell) : "";
                if (!Strings.isNullOrEmpty(value)) {
                    valueMap.put(headerName, value);
                } else if (putEmptyValue) {
                    valueMap.put(headerName, "");
                }
            }
        }
        return valueMap;
    }
}