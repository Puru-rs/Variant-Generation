package xmlgenerator;

/**
 * Created by harshithgn on 7/27/2018.
 */

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import excelpacks.ExcelClasses;
import org.apache.commons.io.FileUtils;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import nu.xom.Elements;

public class ExcelToXMLConvertionTool {

    ModifyXMLFile mxf = null;

    public ExcelToXMLConvertionTool() {
        mxf = new ModifyXMLFile();
    }

    @Test
    public void generateXMLFromExcel() {
        try {
            System.out.println("Kindly hold on while we generate the xml files to you..!!");
            String excelFilePath = System.getProperty("user.dir") + "/inputFiles/Master.xlsx";
            excelFilePath = excelFilePath.replace("\\", "/");
            try {
                XSSFWorkbook workbook = null;
                FileInputStream inputStream;
                try {

                    inputStream = new FileInputStream(new File(excelFilePath));
                    workbook = new XSSFWorkbook(inputStream);
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                List<String> helpList = new ArrayList<String>();
                helpList = ExcelClasses.getHelpContent("Help", workbook);
                int numberOfEntities = Integer.parseInt(helpList.get(0).trim().toString());
                String sheetName = helpList.get(2).trim().toString();
                String outputFolderPath = helpList.get(3).trim().toString();

                int metadataRowCountSku = ExcelClasses.getRowCount(sheetName, workbook);
                int columCountSku = ExcelClasses.getColCount(sheetName, workbook);

                FileWriter writer = null;

                String filepath = System.getProperty("user.dir") + "/inputFiles/" + helpList.get(1).trim().toString();
                filepath = filepath.replace("\\", "/");
                FileUtils.cleanDirectory(new File(outputFolderPath));
                Thread.sleep(3000);
                mxf.generateItems(filepath, numberOfEntities, outputFolderPath, workbook, sheetName);
                System.out.println("Kindly hold on while we generate the usable xml files to you..!!");
                Thread.sleep(3000);
                File dir = new File(outputFolderPath);
                File[] filesInDir = dir.listFiles();
                File f = null;
                Document doc = null;
                List<String> ExcelMetadata = null;
                int i = 1, ph = 1, temp = 1;

                for (int file = 1; file <= filesInDir.length; file++) {
                    String fileName = outputFolderPath + "/" + helpList.get(4).toString().trim() + file + ".xml";
                    i = ph;
                    temp = 1;
                    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                    doc = docBuilder.parse(fileName);

                    while (i != 0) {

                        //get all the item
                        NodeList itemList = doc.getElementsByTagName("Item"); //get all the item int he file
                        for (; temp <= itemList.getLength(); i++, temp++) {
                            ExcelMetadata = ExcelClasses.ReadMetadata(sheetName, i, workbook);
                            Node eachItemNode = itemList.item(temp - 1);
                            NodeList eachItemNodeList = eachItemNode.getChildNodes();
                            for (int hp = 0; hp < ExcelMetadata.size(); hp++) {


                                for (int j = 0; j < eachItemNodeList.getLength(); j++) {  //eachItemNodeList iterate through all the child attribute of each item

                                    Node node = eachItemNodeList.item(j);

                                    // get the element, and update the value
                                    if ((ExcelMetadata.get(hp).split(Pattern.quote("$"))[0].trim().toString()).equals(node.getNodeName())) {
                                        node.setTextContent((ExcelMetadata.get(hp).split(Pattern.quote("$"))[1].trim().toString()));
                                        break;
                                    }
                                }
                            }

                            if (temp == itemList.getLength()) {
                                ph = ++i;
                                i = 0;
                                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                                Transformer transformer = transformerFactory.newTransformer();
                                DOMSource source = new DOMSource(doc);
                                StreamResult result = new StreamResult(new File(String.valueOf(fileName)));
                                transformer.transform(source, result);

                                System.out.println("Updated '" + fileName + "'");
                                break;
                            }
                        }
                    }
                }
            } catch (ParserConfigurationException pce) {
                pce.printStackTrace();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            } catch (SAXException sae) {
                sae.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
