package xmlgenerator;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;
import excelpacks.ExcelClasses;
import nu.xom.*;
import nu.xom.Document;
import nu.xom.Element;
import nu.xom.Node;
import nu.xom.converters.DOMConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.*;
import org.xml.sax.SAXException;
import sun.misc.IOUtils;
import sun.security.krb5.Config;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.ArrayList;


/**
 * Created by paramashivaiahp on 7/30/2018.
 */
public class ModifyXMLFile {

    public void generateItems(String filePath, int numOfEntitiesPerFile, String outputFolderPath, XSSFWorkbook workbook, String sheetName) {
        try {

            ModifyXMLFile mxfx = new ModifyXMLFile();
            Builder builder = new Builder();

            InputStream ins = new FileInputStream(filePath);
            Document doc = builder.build(ins);

            try {
                mxfx.append(doc, numOfEntitiesPerFile, outputFolderPath, workbook, sheetName, filePath);
            } catch (TransformerException e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void append(Document doc, int numberOfEntitiesPerFile, String outputFolderPath, XSSFWorkbook workbook, String sheetName, String filePath) throws TransformerException, ParserConfigurationException {

        try {
            java.util.List<String> helpList = new ArrayList<String>();

            helpList = ExcelClasses.getHelpContent("Help", workbook);


            Element root = doc.getRootElement();
            Element items = (Element) root.getChild(3);
            Node item = null;

            int temp = 1, entitiesRowCount = 1, fName = 0;
            int excelRowCount = ExcelClasses.getRowCount(sheetName, workbook);
            for (; entitiesRowCount <= excelRowCount; entitiesRowCount++, temp++) {
                item = root.getChild(3).getChild(1);
                Element itemElement = new Element((Element) item);
                items.appendChild(itemElement);

                if (temp == numberOfEntitiesPerFile) {
                    if (temp % numberOfEntitiesPerFile == 0) {
                        fName++;

                        if (entitiesRowCount != excelRowCount) {
                            items.removeChild(temp);
                            writeTheFile(doc, outputFolderPath, fName, helpList.get(4).toString().trim());
                            Builder builder = new Builder();
                            InputStream ins = new FileInputStream(filePath);
                            doc = null;
                            root = null;
                            items = null;
                            doc = builder.build(ins);
                            root = doc.getRootElement();
                            items = (Element) root.getChild(3);
                        } else if (entitiesRowCount == excelRowCount) {
                            items.removeChild(1);
                            writeTheFile(doc, outputFolderPath, fName, helpList.get(4).toString().trim());
                        }
                    }

                    temp = 0;
                } else if (entitiesRowCount == ExcelClasses.getRowCount(sheetName, workbook)) {
                    fName++;
                    items.removeChild(1);
                    writeTheFile(doc, outputFolderPath, fName, helpList.get(4).toString().trim());
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void writeTheFile(Document doc, String outputFilePath, int outputFileNameNumber, String outputFilePrefix) {
        try {
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            DOMImplementation impl = builder.getDOMImplementation();
            org.w3c.dom.Document w3cDoc = DOMConverter.convert(doc, impl);
            DOMSource source = new DOMSource((org.w3c.dom.Node) w3cDoc);
            StreamResult result = new StreamResult(new File(outputFilePath + "/"+ outputFilePrefix + outputFileNameNumber + ".xml"));
            transformer.transform(source, result);

            System.out.println("Created virtual copy of '" + outputFilePath + "/"+outputFilePrefix + outputFileNameNumber + ".xml'");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
