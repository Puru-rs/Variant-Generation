package xmlgenerator;

import excelpacks.ExcelClasses;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
 * Created by harshithgn on 6/8/2018.
 */
public class XMLGenerator {

    @Test
    public void generateXML() {

        for (int nf = 1; nf <= 1; nf++) {
            String excelFilePath = System.getProperty("user.dir") + "\\inputFiles\\WB2.xls";
            try {
                // String jsonName = nf + ").xls";
                // excelFilePath = excelFilePath+ jsonName;
                // Using HHSFWorkbook in order to support xls files which can be
                // processed with more than 20K records.
                HSSFWorkbook workbook = null;
                FileInputStream inputStream;
                try {

                    inputStream = new FileInputStream(new File(excelFilePath));  //excelFilePath will have the input file name and path
                    workbook = new HSSFWorkbook(inputStream);
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                FileWriter writer = null;
                int metadataRowCountSku = ExcelClasses.getRowCount("Entities", workbook);
                int columCountSku = ExcelClasses.getColCount("Entities", workbook);

                int noOfEntities = 1000;
                List<String> ExcelMetadata = null;
                int file = 0;
                // boolean isSingleLocale = false;

                int temp = 1;
                int skuRowCount = 1;
                int fName = 1;
                ExcelMetadata = ExcelClasses.ReadMetadata1("Entities",1, workbook);
                //writer = new FileWriter(System.getProperty("user.dir") + "\\oneMillionJsonOutput\\Sku\\2k_Entities_Create\\Sku1k_" + fName + ".json");
                System.out.println("Created " + fName + ".json");

                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document document = builder.newDocument();

                //PIES Tag
                Element rootElement = document.createElement("PIES");
                rootElement.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance");
                rootElement.setAttribute("xsi:schemaLocation", "http://www.autocare.org PIES_6_7_(rev4)_XSD_20161228.xsd");
                rootElement.setAttribute("xmlns", "http://www.autocare.org");
                document.appendChild(rootElement);

                //PIES.HEADER Tag
                Element headerElement = document.createElement("Header");
                rootElement.appendChild(headerElement);

                //PIES.HEADER.PIESVERSION Tag
                createElementWithValue(document, "PIESVersion", headerElement, "6.8");

                //PIES.HEADER.SUBMISSIONTYPE Tag
                createElementWithValue(document, "SubmissionType", headerElement, "FULL");

                //PIES.HEADER.BLANKEFFECTIVEDATE
                createElementWithValue(document, "BlanketEffectiveDate", headerElement, "2018-04-11");

                //PIES>HEADER.PARENTAAIAID
                createElementWithValue(document, "ParentAAIAID", headerElement, "BFGR");

                //PIES.HEADER.BRANDOWNERAAIAID
                createElementWithValue(document, "BrandOwnerAAIAID", headerElement, "BFGR");

                //PIES.HEADER.CURRENCYCODE
                createElementWithValue(document, "CurrencyCode", headerElement, "USD");

                //PIES.HEADER.LANGUAGECODE
                createElementWithValue(document, "LanguageCode", headerElement, "EN");

                //PIES.HEADER.TECHNICALCONTACT


                Element headerElement1 = document.createElement("Item");
                headerElement1.setAttribute("MaintenanceType", "A");
                headerElement1.setAttribute("DescriptionCode", "DES");
                //productElement.appendChild(headerElement);
                //headerElement.appendChild(document.createTextNode("hi"));


                TransformerFactory tFactory = TransformerFactory.newInstance();

                Transformer transformer = tFactory.newTransformer();
                //Add indentation to output
                transformer.setOutputProperty
                        (OutputKeys.INDENT, "yes");
                transformer.setOutputProperty(
                        "{http://xml.apache.org/xslt}indent-amount", "2");

                DOMSource source = new DOMSource(document);
                StreamResult result = new StreamResult(new File(System.getProperty("user.dir")+ "\\" + "products.xml"));
                //StreamResult result = new StreamResult(System.out);
                transformer.transform(source, result);


            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public void createElementWithValue(Document document, String elementName, Element parentElement, String elementValue){
        Element childElement = document.createElement(elementName);
        parentElement.appendChild(childElement);
        childElement.appendChild(document.createTextNode(elementValue));
    }
}
