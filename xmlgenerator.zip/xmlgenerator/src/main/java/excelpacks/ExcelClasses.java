package excelpacks;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CellRange;
import org.apache.poi.ss.util.CellRangeAddress;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by harshithgn on 6/8/2018.
 */
public class ExcelClasses {

    public static List<String> ReadMetadata(String SheetName, int RowNumber, HSSFWorkbook workbook)
            throws NullPointerException {
        List<String> ExcelData = new ArrayList<String>();

        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String CellValue = null;
        String[] ary = null;
        String Value = null;
        try {
            // Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheet(SheetName);
            HSSFRow row = sheet.getRow(RowNumber);
            HSSFRow Headerrow = sheet.getRow(0);
            String Header = null;

            Boolean entered = false; // set entered to true once cell data is read
            for (int j = 0, h=0; j <= Headerrow.getPhysicalNumberOfCells(); j++, h++) {
                try {
                    CellType = row.getCell(j).getCellType();
                    for (int i = 0; i < sheet.getNumMergedRegions(); i++) {
                        CellRangeAddress region = sheet.getMergedRegion(i); //Region of merged cells
                        int getFirstCol = region.getFirstColumn();
                        int getLastCol = region.getLastColumn();
                        if (j == region.getFirstColumn()) {
                            for(int k=getFirstCol; k <= getLastCol; k++){

                                if(k==getFirstCol) {
                                    Header = Headerrow.getCell(k).toString();
                                    System.out.println(Header + "$" + sheet.getRow(row.getRowNum()).getCell(k).getStringCellValue());
                                    ExcelData.add(Header + "$" + sheet.getRow(row.getRowNum()).getCell(k).getStringCellValue());
                                    entered = true;
                                } else{
                                    System.out.println(sheet.getRow(row.getRowNum()).getCell(k).getStringCellValue());
                                    ExcelData.add(sheet.getRow(row.getRowNum()).getCell(k).getStringCellValue());
                                    entered = true;
                                }
                                j=getLastCol;
                            }

                        } else if (entered == false){
                            if (CellType > -1) {
                                switch (CellType) {
                                    case 0:
                                        Header = Headerrow.getCell(j).toString();
                                        NumericCellValue = row.getCell(j).getNumericCellValue();
                                        String stringCellValue = NumericCellValue.toString();
                                        System.out.println(stringCellValue);
                                        ary = stringCellValue.split(Pattern.quote("."));
                                        int wholeNum = Integer.parseInt(ary[0]);
                                        if (NumericCellValue % wholeNum == 0) {
                                            Value = Header + "$" + ary[0];
                                            System.out.println(stringCellValue);
                                        } else {
                                            Value = Header + "$" + NumericCellValue;
                                            System.out.println(stringCellValue);
                                        }
                                        ExcelData.add(Value);
                                        entered = true;
                                        // ExcelData.add(CellValue);
                                        break;
                                    case 1:
                                        Header = Headerrow.getCell(j).toString();
                                        CellValue = row.getCell(j).toString();
                                        if (CellValue.equals("NA")) {

                                        } else {
                                            String Value1 = Header + "$" + CellValue;
                                            ExcelData.add(Value1);
                                            System.out.println(Value1);
                                            entered = true;
                                        }

                                    case 3:
                                    default:
                                }
                            }

                        }
                    }
                } catch (Exception expt) {
                    continue;
                }
                entered = false;
            }
        } catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }

        return ExcelData;

    }

    public static List<String> ReadMetadata1(String SheetName, int RowNumber, HSSFWorkbook workbook)
            throws NullPointerException {
        List<String> ExcelData = new ArrayList<String>();
        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String mergedValues = "";
        String[] ary = null;
        String Value = null;
        Boolean foundRegion = false;
        Boolean foundMerged = false;
        try {
            // Get first/desired sheet from the workbook
            HSSFSheet sheet = workbook.getSheet(SheetName);
            HSSFRow row = sheet.getRow(RowNumber);
            HSSFRow Headerrow = sheet.getRow(0);
            HSSFCell cell = Headerrow.getCell(1);
            String Header = null;

            int range = sheet.getNumMergedRegions();
            List<CellRangeAddress> regionsList = new ArrayList<CellRangeAddress>();
            for(int i = 0; i < range; i++) {
                regionsList.add(sheet.getMergedRegion(i));
            }
            for (int i = 0; i < Headerrow.getPhysicalNumberOfCells(); i++) {
                HSSFCell regions = Headerrow.getCell(i); //Region of merged cells
                //System.out.println(regions);
                for(CellRangeAddress region : regionsList) {
                    // If the region does contain the cell you have just read from the row
                    if(region.isInRange(regions.getRowIndex(), regions.getColumnIndex())) {
                        // Now, you need to get the cell from the top left hand corner of this
                        int rowNum = region.getFirstRow();
                        int colIndex = region.getFirstColumn();
                        cell = sheet.getRow(rowNum).getCell(colIndex);
                       // System.out.println("Cel is in merged region. The value stored in that region is " +  cell.getStringCellValue());
                        foundRegion=true;
                        System.out.println(regions + "$" + sheet.getRow(row.getRowNum()).getCell(i).getStringCellValue());
                        mergedValues = mergedValues + regions + "$" + sheet.getRow(row.getRowNum()).getCell(i).getStringCellValue();
                    }
                    if(foundRegion && i==region.getLastColumn())
                    {
                        ExcelData.add(mergedValues);
                        mergedValues="";
                    }

                }
                if(!foundRegion){
                    System.out.println(regions + "$" + sheet.getRow(row.getRowNum()).getCell(i).getStringCellValue());
                    ExcelData.add(regions + "$" + sheet.getRow(row.getRowNum()).getCell(i).getStringCellValue().trim());
                }
                foundRegion=false;

            }
        } catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }

        return ExcelData;

    }


            public static int getRowCount(String SheetName, HSSFWorkbook workbook) {
        int rowCount = 0;
        try {
            HSSFSheet sheet = workbook.getSheet(SheetName);
            rowCount = sheet.getLastRowNum();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return rowCount;
    }

    public static int getColCount(String SheetName, HSSFWorkbook workbook) {
        int CollCount = 0;
        try {
            HSSFSheet sheet = workbook.getSheet(SheetName);
            CollCount = sheet.getRow(0).getPhysicalNumberOfCells();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return CollCount;
    }

}
