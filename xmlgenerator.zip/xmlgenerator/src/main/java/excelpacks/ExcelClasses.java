package excelpacks;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by harshithgn on 6/8/2018.
 */
public class ExcelClasses {

    public static List<String> ReadMetadata(String sheetName, int rowNumber, XSSFWorkbook workbook)
            throws NullPointerException {
        List<String> ExcelData = new ArrayList<String>();

        int CellType;
        Double NumericCellValue;
        int TempCellValue = 0;
        String CellValue = null;
        String[] ary = null;
        String Value = null;
        try {
            // Get first/desired sheet from the workbook
            XSSFSheet sheet = workbook.getSheet(sheetName);
            XSSFRow row = sheet.getRow(rowNumber);
            XSSFRow Headerrow = sheet.getRow(0);
            String Header = null;

            for (int j = 0; j <= Headerrow.getPhysicalNumberOfCells(); j++) {
                try {
                    CellType = row.getCell(j).getCellType();

                    if (CellType > -1) {
                        switch (CellType) {
                            case 0:
                                Header = Headerrow.getCell(j).toString();
                                NumericCellValue = row.getCell(j).getNumericCellValue();
                                String stringCellValue = NumericCellValue.toString();
                                ary = stringCellValue.split(Pattern.quote("."));
                                int wholeNum = Integer.parseInt(ary[0]);
                                if (NumericCellValue % wholeNum == 0) {
                                    Value = Header + "$" + ary[0];
                                } else {
                                    Value = Header + "$" + NumericCellValue;
                                }
                                ExcelData.add(Value);
                                // ExcelData.add(CellValue);
                                break;
                            case 1:
                                Header = Headerrow.getCell(j).toString();
                                CellValue = row.getCell(j).toString();
                                if (CellValue.equals("NA")) {

                                } else {
                                    String Value1 = Header + "$" + CellValue;
                                    ExcelData.add(Value1);
                                }
                                break;
                            case 3:
                            default:
                        }
                    }
                } catch (Exception expt) {
                    continue;
                }
            }
        } catch (NullPointerException npe) {
            System.out.println("Hi");
            // return Result;
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }

        return ExcelData;

    }

    public static int getRowCount(String sheetName, XSSFWorkbook workbook) {
        int rowCount = 0;
        try {
            XSSFSheet sheet = workbook.getSheet(sheetName);
            rowCount = sheet.getLastRowNum();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return rowCount;
    }

    public static int getColCount(String sheetName, XSSFWorkbook workbook) {
        int CollCount = 0;
        try {
            XSSFSheet sheet = workbook.getSheet(sheetName);
            CollCount = sheet.getRow(0).getPhysicalNumberOfCells();
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println(ex.toString());
        }
        return CollCount;
    }

    public static List<String> getHelpContent(String sheetName, XSSFWorkbook workbook) {
        List<String> helpData = new ArrayList<String>();
        try {
            //this.fileName = fileName;
            XSSFSheet sheet = workbook.getSheet(sheetName);

            helpData.add(workbook.getSheet("Help").getRow(6).getCell(1).getStringCellValue().toString()); //numberOfEntites/File
            helpData.add(workbook.getSheet("Help").getRow(7).getCell(1).getStringCellValue().toString()); //referenceXMLInputFile
            helpData.add(workbook.getSheet("Help").getRow(8).getCell(1).getStringCellValue().toString()); //sheetName
            helpData.add(workbook.getSheet("Help").getRow(9).getCell(1).getStringCellValue().toString()); //outputPath
            helpData.add(workbook.getSheet("Help").getRow(10).getCell(1).getStringCellValue().toString()); //outputFilePrefix

        } catch (Exception e) {
            e.printStackTrace();
        }
        return helpData;
    }

}
