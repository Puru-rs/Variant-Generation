package functional;

import com.google.common.base.Strings;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import utilities.ExcelUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import java.util.regex.Pattern;

import static org.apache.commons.lang3.StringUtils.isBlank;

public class MDM_CompareDataModel {

    @Parameters({"riverworksFile", "clientFile"})
    @Test
    public void readModelFile(String riverworksFile, String clientFile) {
        try {
            XSSFWorkbook clientWorkBook = accessWorkbook(clientFile);
            XSSFWorkbook riverworksWorkBook = accessWorkbook(riverworksFile);

            Map<String, Integer> clientHeaderMap = ExcelUtil.readColumns(clientWorkBook.getSheet("ATTRIBUTES"), 0);
            Map<String, Integer> riverworksHeaderMap = ExcelUtil.readColumns(clientWorkBook.getSheet("ATTRIBUTES"), 0);

            Map<String, List<Map<String, String>>> clientExcelGroup = new LinkedHashMap<>(),
                    riverworksExcelGroup = new LinkedHashMap<>();

            List<String> mergedColumn = new ArrayList<>();
            mergedColumn.add("DATA TYPE");

            clientExcelGroup = MDM_CompareDataModel.GetMapExcel(clientWorkBook, mergedColumn, "DATA TYPE", clientHeaderMap, 1, "ATTRIBUTES");
            riverworksExcelGroup = MDM_CompareDataModel.GetMapExcel(riverworksWorkBook, mergedColumn, "DATA TYPE", riverworksHeaderMap, 1, "ATTRIBUTES");

            System.out.println("HI");

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }



    private XSSFWorkbook accessWorkbook(String clientFile) throws IOException {
        File clientFilePath = new File(clientFile);
        FileInputStream importFileInputStream = new FileInputStream(clientFilePath);
        return new XSSFWorkbook(importFileInputStream);
    }

    private static Map<String, List<Map<String, String>>> GetMapExcel(XSSFWorkbook clientWB, List<String> mergedColumn, String idColumnName, Map<String, Integer> importHeaderMap, int rowNo, String sheetName) {
        Map<String, List<Map<String, String>>> importExcelGroup = new LinkedHashMap<>();
        Map<String, List<Map<String, String>>> importIdExcelGroup = new LinkedHashMap<>();
        Iterator<Row> importRowIterable = clientWB.getSheet(sheetName).rowIterator();
        while (importRowIterable.hasNext()) {
            Row row = importRowIterable.next();
            if (row.getRowNum() < rowNo) continue;
            Map<String, String> valueMap = ExcelUtil.getValues(importHeaderMap, row, true);
            String idValue = valueMap.get(idColumnName);
            StringJoiner keyBuilder = new StringJoiner("#@#");
            for (String columnName :
                    mergedColumn) {
                String value = valueMap.getOrDefault(columnName, "");
                if (!Strings.isNullOrEmpty(value)) {
                    keyBuilder.add(columnName + "||" + value);
                }
            }
            if (Strings.isNullOrEmpty(keyBuilder.toString())) {
                List<Map<String, String>> idValueList = importIdExcelGroup.computeIfAbsent(idValue, k -> new ArrayList<>());
                if (!idValueList.contains(valueMap)) {
                    idValueList.add(valueMap);
                }
            } else {
                List<Map<String, String>> idValueList = importIdExcelGroup.computeIfAbsent(idValue, k -> new ArrayList<>());
                if (!idValueList.contains(valueMap)) {
                    idValueList.add(valueMap);
                    importExcelGroup.put(keyBuilder.toString(), idValueList);
                }
            }
        }
        return importExcelGroup;
    }

    public static Map<String, Integer> readColumns(XSSFSheet sheet, int rowNo) {
        Map<String, Integer> columns = new TreeMap<>();
        if (sheet != null) {
            XSSFRow header = sheet.getRow(rowNo);
            for (Cell headerCell : header) {
                String value = headerCell.getStringCellValue();
                if (isBlank(value)) {
                    break;
                }

                columns.put(value, headerCell.getColumnIndex());
            }
        }
        return columns;
    }
}
